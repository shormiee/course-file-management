 <?php include('header_essential.php'); ?>

<?php
session_start();
 include_once("includes/connection.php");

$dept_name = $_POST['dept_name']; 
$sql = mysqli_query($conn, "SELECT dept_code, email FROM 04_department WHERE dept_name = '".$dept_name."' ");
$row = mysqli_fetch_array($sql);

json_encode($row);
die;
?> 
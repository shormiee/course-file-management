<?php
    include_once('header_essential.php'); 

    session_start();
     include_once("includes/connection.php");
    $deptId = $_SESSION['deptid'];

    if (isset($_POST['save'])) {

     $name = $_POST['name'];
     $email = $_POST['email'];
     $dept = $_POST['dept'];
     $status = $_POST['status'];

$id = $_GET['id'];
$query = "UPDATE `05_teacher` SET `name`='$name',`deptid`='$dept',`email`='$email',`status_05`=$status WHERE id = '$id'";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}

?>

<body>

<div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>
 <h5 class="text-center"> <?php echo $_SESSION['name'] . ", you are accessing department admin panel" ?></h5>; 
  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
      <a href="./d_see_courses.php">
    </div>
 <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

  <?php
     $page = "d_3";
    include ("./d_main_nav.php");
     ?>

  </div>
  <div class="col-md-9">
      <div class="justify-content-center">
        <div class="col-md-8 shadow-sm" style="margin-top:30px;">
        <?php

            $id = $_GET['id'];
            $std = "SELECT * FROM `05_teacher` WHERE id = '$id'";
            $run = mysqli_query($conn, $std);
            while ($data = mysqli_fetch_assoc($run)):
        ?>

        <form method="post">
            <h3 class="text-left my-3">Edit Course</h3>
                    
            <label>Name</label>
            <input type="text" name="name" class="form-control my-2" placeholder="Enter teacher name" value="<?php echo $data['name'] ?>" autocomplete="off" required>

            <label>Email</label>
            <input type="text" name="email" class="form-control my-2" placeholder="Enter email address" value="<?php echo $data['email'] ?>" autocomplete="off" required>

            <label>Department</label>
            <select name="dept" id="dept" class="form-control my-2" required>
            <?php 
            $sql = "SELECT * from 04_department WHERE status_04 = 1";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo $rows['id']; ?>"
                <?php echo ($rows['id'] ==$data['deptid']) ? "selected" : ""; ?>
                >
                <?php echo $rows["dept_name" ];?>
                 </option>
                 <?php } ?>
            </select>

            <label style="margin-top: 15px;">Status</label>
            <select name="status" class="form-control my-2">
              <option value="1"
              <?php echo ("1" ==$data['status_05']) ? "selected" : ""; ?>
              >Active</option>
              <option value="0"
              <?php echo ("0" ==$data['status_05']) ? "selected" : ""; ?>
              >Deactive</option>
            </select>

            <input type="submit" name="save" class="btn bg-dark text-white" value="Update">
        <?php endwhile; ?>
          </form>
        </div>
      </div>
    </div>
</div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>
</html>  


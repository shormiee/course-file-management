<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "home";

$conn = new mysqli($servername, $username, $password, $db_name);
// $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 if ($conn->connect_error) { 
       die("Connection failed: " . $conn->connect_error); 
   }
   else {
	//echo "connected";
   }

?>
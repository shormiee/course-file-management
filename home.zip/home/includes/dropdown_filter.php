   <?php
     include_once("includes/connection.php");
     if (!isset($_SESSION['current_year'])) {
       $setting_q = "SELECT * FROM `09_settings` WHERE id =(SELECT MAX(id) FROM `09_settings`)";
        $setting = mysqli_query($conn, $setting_q);
        $s_row = mysqli_fetch_assoc($setting);
        //echo $s_row['current_year'];
        $_SESSION['current_year'] = $s_row['current_year'];
        $_SESSION['current_semester'] = $s_row['current_semester'];
     }
  
  $role = $_SESSION['role'];

  $deptId = $_SESSION['deptid'];
  $sql = "SELECT * FROM 04_department WHERE id = '$deptId'";
  $result = mysqli_query($conn, $sql);
  while ($rows = mysqli_fetch_assoc($result)):
    $_SESSION['program_code'] = $rows["program_code"];

    if(isset($_POST["semester"]) || isset($_POST["cy"])){
       $semester=$_POST["semester"];
       $cy=$_POST["cy"];
       $_SESSION['current_year'] = $cy;
       $_SESSION['current_semester'] = $semester;
       //echo "select country is => ".$cy.$semester;
       
   }
?>
<form method="POST" action="">
  <div class="row">
    <div class="col-md-1"></div>
  <div class="col-md-4">
      <input class="form-control" type="text" name="dept" value="<?php echo $rows["dept_name"]; ?>" readonly>
    </div>
    <div class="col-md-2">
      <input class="form-control" type="text" name="prog_code" value="<?php echo $rows["program_code"]; ?>" readonly>
    </div>
    <?php endwhile; ?>
  

  <div class="col-md-2">
    <select class="form-control" id="cy" name="cy" <?php echo ($role == '3' || $role == '4') ? 'disabled' : ''; ?> onchange="this.form.submit()">
      <option value="none" disabled selected>Year</option>
      <?php
        $years = array("2010", "2011", "2012","2013", "2014", "2015","2016", "2017", "2018","2019", "2020", "2021","2022");
        foreach($years as $year):
      ?>
      <option value="<?php echo $year; ?>" <?php echo ($_SESSION['current_year'] == $year) ? 'selected':'' ?>><?php echo $year; ?></option>
      <?php endforeach; ?>
    </select>
  </div>


<!--   <div class="col-auto">
    <input type="text" class="<?php echo ($role == '3' || $role == '4') ? '' : 'yearpicker'; ?>" value="<?php echo $s_row['current_year'] ?>" name="cy" <?php echo ($role == '3' || $role == '4') ? 'disabled' : ''; ?>>
  </div> -->
  <div class="col-md-2">
    <select class="form-control" id="semester" name="semester" <?php echo ($role == '3' || $role == '4') ? 'disabled' : ''; ?> onchange="this.form.submit()">
      <option value="none" disabled selected>Choose Semester</option>
      <option value="fall" <?php echo ($_SESSION['current_semester'] == 'fall') ? 'selected' : ''; ?>>Fall</option>
      <option value="spring" <?php echo ($_SESSION['current_semester'] == 'spring') ? 'selected' : ''; ?>>Spring</option>
      <option value="summer" <?php echo ($_SESSION['current_semester'] == 'summer') ? 'selected' : ''; ?>>Summer</option>
    </select>
  </div>
  </div>
</form>


<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<link rel="stylesheet" href="css/yearpicker.css" />
<script src="js/yearpicker.js"></script>
<script type="text/javascript">
$(document).ready(function() {
  var current = $(".yearpicker").val();
   $(".yearpicker").yearpicker({
      year: 2022,
      startYear: 2010,
      endYear: 2030,
   });
});
</script>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-text text-white" style="padding-right: 50px;">course file management</span>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav me-auto">               
                <!--    <li class="nav-item">
                        <a href="./Deptadmin.html" class="nav-link active">
                            <i class="bi bi-speedometer2"> </i>Home</a>                
                    </li> -->

       
        <li class="nav-item">
                        <a href="./admin-add-teacher.html" class="nav-link ">
                            <i class="bi bi-people"> </i>Teacher</a>                
                    </li>
                      <li class="nav-item">
               <a href="./dadmin-add-std.html" class="nav-link ">
                 <i class="bi bi-people"> </i>Student</a>                
             </li>
        <li class="nav-item">
             <a href="./courses.html"class="nav-link ">
              <i class="bi bi-book"> </i>Course</a>                
           </li>
               <li class="nav-item">
             <a href="./course-file.html" class="nav-link ">
              <i class="bi bi-book"> </i>Course File</a>                
           </li>
           
      
      </ul>
      <ul class="navbar-nav">

       <li class="nav-item dropdown bg-dark text-white">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="glyphicon glyphicon-user" aria-hidden="true"></span> <i class="bi bi-person-circle"></i>

            Dept Admin
          </a>
          <ul class="dropdown-menu user-dropdown" aria-labelledby="navbarDropdownMenuLink">
           <!--  <li><a class="dropdown-item" href="#">change avatar</a></li> -->
            <li><a class="dropdown-item" href="#">change password</a></li>
                <li><a class="dropdown-item" href="#">log out</a></li>
           
          </ul>
        </li>
        </ul>
    </div>
  </div>
</nav>
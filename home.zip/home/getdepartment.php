<?php
include_once("includes/connection.php");
if($_REQUEST['rid']) {
	$sql = "SELECT dept_name, dept_code, total_credit, program_code, email  FROM 04_department 
WHERE id='".$_REQUEST['rid']."'";
	$res = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));	
	$data = array();
	while( $rows = mysqli_fetch_assoc($res) ) {
		$data = $rows;
	}
	echo json_encode($data);
} else {
	echo 0;	
}
?>
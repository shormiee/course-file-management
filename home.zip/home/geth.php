   <?php include('header_essential.php'); ?>

   <body>
    <form>
        User
        <select name="dept_name" id="dept_name">
          <option>-- Select User --</option>
       <?php  echo "<option value='". $dept_name' ."'>" .$dept_name ."</option>"; ?>
         
        </select>

        <p>

          Age 
          <input type="text" name="dept_code" id="dept_code">

        </p>
        <p>
          Email 
          <input type="text" name="email" id="email">
        </p>
        </form>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
    $('#dept_name').on('change',function(){
        var dept_name = $(this).val();
        $.ajax({
            url : "./cfms/get.php",
            dataType: 'json',
            type: 'POST',
            async : false,
            data : { dept_name : dept_name},
            success : function(data) {
                dept_nameData = json.parse(data);
                $('#dept_code').val(dept_nameData.dept_code);
                $('#email').val(dept_nameData.email);
            }
        }); 
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
</body>
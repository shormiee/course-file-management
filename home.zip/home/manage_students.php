 <?php
session_start();

?>

<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
   <input type="button" name="ans" value="submit" class="btn btn-dark" onclick="document.getElementById('sidebar').style.display = 'block' ;" />
  </div>
</div>
  </div>

  <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "d_three";
    include ("./d_main_nav.php");
     ?>
</div>


 <div class="col-md-8">
      <div class="justify-content-center" style="margin-top:30px;">
        <div class="col-md-8 shadow-sm" style="margin-bottom:30px;">
          <form method="post">
            <h3 class="text-left my-3">Add New Student</h3>
            <div class="text-center"></div>
              <label>Choose Course</label>
            <select name="role" class="form-control my-2">
              
              <option value="Super Admin">CSE-101</option>
              <option value="Admin">CSE-201</option>
              <option value="Teacher">CSE-301</option>
               <option value="Teacher">CSE-401</option>
                <option value="Teacher">CSE-0201</option>
                 <option value="Teacher">CSE-302</option>
            
            </select>
            <label>Teacher's Name</label>

    <select name="role" class="form-control my-2">
              <option value="none" disabled="">Choose </option>
              <option value="Super Admin">Md: Shamim </option>
              <option value="Admin">Shila </option>
              <option value="Teacher">Md: Shamim</option>
               <option value="Teacher">Shila</option>
             
            
            </select>

            
          <!--   <label>Department ID</label>
              <input type="id" name="id" class="form-control my-2" placeholder="ID/Employee ID">
            <label>Password</label>
            <input type="password" name="pass" class="form-control my-2" placeholder="Enter Password"> -->

            <input type="save" name="save" class="btn bg-dark text-white" style="margin-bottom:30px;margin-top:20px;" value="save">
          </form>
        </div>
      </div>
    </div>
    </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
  </body>
<?php include('header_essential.php'); ?>
<?php
session_start();

include_once("includes/connection.php");

?>

<body>
 <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>
 
 <!--  <div class="container"> -->
  <div class="row">
   <div class="col-3 col-sm-3">

    <?php
     $page = "two"; 
    include ("./super_admin_sidenav.php");
     ?>
    
  </div>



<div class="col-sm-8" style="margin-top:30px; margin-right: auto;"> 

<?php 

  $query = 'SELECT * FROM 04_department WHERE id ='.$_GET['id'];
  $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

   while($row = mysqli_fetch_array($result)){
   $dept_name = $row['dept_name'];
         $zz = $row['id'];
   $dept_code = $row['dept_code'];
       $email = $row['email'];
$total_credit = $row['total_credit'];
$program_code = $row['program_code'];
        $sts = $row['status_04'];
}

$id = $_GET['id'];
?>

<div class="justify-content-center"> 
      <div class="col-md-8 shadow-sm">
         <h3 class="text-left my-3">Update Department</h3>
          <form method="post" action="update_dept.php">
           
            <div class="text-center"></div>
 <label>Department Name</label>
       <input type="text" name="dept_name" id="deptname" class="form-control my-2" value="<?php echo $dept_name; ?>">
        <input type="hidden" name="id" value="<?php echo $zz; ?>" />

     <label>Department Code</label>
            <input type="text" name="dept_code" id="deptcode" class="form-control my-2" value="<?php echo $dept_code; ?>">

            <label>Program Code</label> 
            <input type="text" name="program_code" id="prog_code" class="form-control my-2" value="<?php echo $program_code; ?>">
           
             <label>Total Credit Hours</label>
            <input type="number" name="total_credit" id="t_credit" class="form-control my-2" value="<?php echo $total_credit; ?>" >

   
 <label>Email</label>
 <input type="text" name="email" id="email" class="form-control my-2" value="<?php echo $email; ?>">
      
       <div class="text-left  my-2" > 


       <select class="form-select  my-2" aria-label="Default select example" name="sts">
  <option value="" disabled selected >Update Status</option>
  <option value="1">Activate</option>
  <option value="0">Deactivate</option>
</select>          
                   <!--  <select name="stas" required="">
                      <option value="none" disabled selected>Choose Status</option>
              <option value="1">activate</option>
              <option value="0">deactivate</option>
            </select> -->
           </div>

            <input type="submit" name="update" value="update" class="btn bg-dark text-white">
    </form>

        </div>
      </div>
    </div>

</body>
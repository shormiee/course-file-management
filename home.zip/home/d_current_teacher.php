<?php
  session_start();
  include_once("includes/connection.php");
?>


<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

</div>
  </div>


 <div class="row">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "crt";
    include ("./d_sidenav.php");
     ?>
</div>

<div class="col-md-5 shadow" style="margin-top: 30px; height: 300px;">

  <h4>Current Teacher</h4>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Teacher's ID</th>
       <th scope="col">Teacher's Name</th>
    </tr>
  </thead>
  <?php
    $course = $_SESSION['courseid'];
    $course_file = "SELECT * FROM `08_course_file` WHERE course_id = '$course'";
    if ($result = mysqli_query($conn, $course_file)):
    while ($row = mysqli_fetch_assoc($result)):
  ?>
    <tr>
      <?php 
          $id = $row['teacher_id'];
          $teacher = "SELECT * FROM `05_teacher` WHERE id = '$id'";
          if ($result1 = mysqli_query($conn, $teacher)):
          $row1 = mysqli_fetch_assoc($result1);
       ?>
      <td><?php echo $row1['id']; ?></td>
      <td><?php echo $row1['name']; endif; ?></td>
    </tr>

 <?php endwhile; endif; ?>
  </tbody>
</table>
</div>

</div>




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


</html>
<?php   
 session_start();

  include_once("includes/connection.php");

   // $output = "";

  if (isset($_POST['login'])) {
    $errorMsg = "";
  	  $role = $_POST['role'];
  	   $uname = $_POST['uname'];
  	   $pass = $_POST['pass'];

       if (!empty($uname) || !empty($pass)) {

       if ($role == "1") {
         $query = "SELECT * FROM 01_superadmin WHERE name ='$uname' AND password ='$pass' AND status_01 = '1'";
         $res = $conn->query($query);

       if ($res->num_rows > 0) {
          $row = $res->fetch_assoc();
          $_SESSION['role'] = "1";
          $_SESSION['name'] = $row['name'];
            $_SESSION['id'] = $row['id'];
          header("Location:super_admin.php");
          die();   
          }

       else {
             $errorMsg = "Invalid username or password.";
         }
      } 
        else if ($role == "2") {
      $query = "SELECT * FROM 02_deptadmin WHERE name ='$uname' AND password ='$pass' AND status_02 = '1'";
         $res = $conn->query($query);
      
            if ($res->num_rows > 0) {
              $row = $res->fetch_assoc();
               
              $_SESSION['name'] = $uname;
              $_SESSION['id'] = $row['id'];
              $_SESSION['deptid'] = $row['deptid'];
              $_SESSION['role'] = "2";

                header("Location:deptadmin.php");
                 die();  
        }
         else {
                   $errorMsg = "Invalid username or password.";
               }
  }


        else if ($role == "3") {
      $query = "SELECT * FROM 03_student WHERE name ='$uname' AND password ='$pass' AND status_03 = '1'";
         $res = $conn->query($query);
     
           if ($res->num_rows > 0) {
                $row = $res->fetch_assoc();
                $_SESSION['name'] = $uname;
                $_SESSION['deptid'] = $row['deptid'];
                $_SESSION['id']=$row['id'];
                $_SESSION['role'] = "3";

                header("Location:student.php");
                 die();  
        }
         else {
                   $errorMsg = "Invalid username or password.";
               }

   }
      else if ($role == "4") {
      $query = "SELECT * FROM 05_teacher WHERE name ='$uname' AND password ='$pass' AND status_05 = '1'";
         $res = $conn->query($query);
       
           if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $_SESSION['name'] = $uname;
            $_SESSION['deptid'] = $row['deptid'];
            $_SESSION['id']=$row['id'];
            $_SESSION['role'] = "4";
                header("Location:teacher.php");
                 die();  
        }
         else {
                   $errorMsg = "Invalid username or password.";
               }

    }
 
      else {
      $errorMsg = "Invalid username or password.";
    }
  }

else {
      $errorMsg = "Username and Password is required";
    }


  }


 ?>

<!DOCTYPE>
<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Course File Management System</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
   <script src="https://unpkg.com/@popperjs/core@2.4.0/dist/umd/popper.min.js"></script>
  <script src="js/bootstrap.js"></script>
</head>
<body>
<div class="mainh"> 
  <div class="container ">

   <div class="col-12 shadow-sm" style="margin-bottom:20px; margin-top:100px; box-shadow: -4px 4rem 3rem 20px rgb(0 0 0 / 8%) !important;
    background: #b5b5b5c7;">
      <div class="row-fluid d-flex justify-content-center">

        <div class="col-6" style="margin-top:150px; padding: 40px;">
        <div class="row">
                 <div class="col-sm-3 ">
            <div class="mitu-home">
              <img class="mimage" src="./assets/unnamed.png">
            </div>
          </div>
            <div class="col-sm-9" style="margin-top: 30px;"> 
                             <h5 class="text-dark">STATE UNIVERSITY OF BANGLADESH</h6>  
                             <p class="text-dark">Join The Trendsetter</p>
               </div>

               <div class="col-3 pb-3">
            
                </div>
               <div class="col-sm-9 "> 
                            <div class="text-dark text-left">
              <!-- <h5 class="text-uppercase">Welcome To: </h5> -->
              <h5 class="text-uppercase bold">Course File Management System</h5>  
                </div>
               </div>
          
        </div> <!--row ends-->
                                        
       </div> <!--col-6 ends-->
        
               <div class="col-md-6 " style="padding: 50px;">
           <?php if (isset($errorMsg)) { ?>
  <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo $errorMsg; ?>

</div>
        <?php } ?>
          <form method="post">
            <h3 class="text-center my-3 text-dark">User Login</h3>
            <label class="text-dark"> Sign in As</label>
                <select name="role" class="form-control my-2">
              <option value="none" disabled selected>Choose option</option>
              <option value="1">Super Admin</option>
              <option value="2">Deparment Admin</option>
              <option value="4">Teacher</option> 
              <option value="3">Student</option>

            </select>
            
            <label class="text-dark">Username</label>
            <input type="text" name="uname" class="form-control my-2" placeholder="Enter Username" autocomplete="off">
            <label class="text-dark">Password</label>
            <input type="password" name="pass" class="form-control my-2" placeholder="Enter Password">
          
                        <div class="d-grid gap-2">

            <input type="submit" name="login"  class="btn btn-dark" value="Sign in">
          </div>
          </form>
        </div>
      </div> <!--row-fluid ends-->
    </div>
  </div>
</div>

</body>
</html>
<?php
    include_once('header_essential.php'); 

    session_start();
     include_once("includes/connection.php");
    $deptId = $_SESSION['deptid'];

    if (isset($_POST['save'])) {

     $course_code = $_POST['code'];
     $course_title = $_POST['title'];
     $semester_name = $_POST['semester_name'];
     $offering_dept = $_POST['offering_dept'];
     $receiving_dept = $_POST['receiving_dept'];
     $current_teacher_id = $_POST['ctid'];
     $credit = $_POST['credit'];
     $program_code = $_SESSION['program_code'];
     $current_year = $_SESSION['current_year'];
     $status = $_POST['status'];


$id = $_GET['id'];
$query = "UPDATE `06_course` SET `course_code`='$course_code',`course_title`='$course_title',`offering_deptid`='$offering_dept',`receiving_deptid`='$receiving_dept',`credit`='$credit',`current_teacher_id`='$current_teacher_id',`semester_name`='$semester_name',`program_code`='$program_code',`year`='$current_year',`status_06`=$status WHERE id = '$id'";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}

?>

<body>
 

<div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>
 <h5 class="text-center"> <?php echo $_SESSION['name'] . ", you are accessing department admin panel" ?></h5>; 
  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
      <a href="./d_see_courses.php">
    </div>
 <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

  <?php
     $page = "d_mfour";
    include ("./d_main_nav.php");
  ?>
  </div>
  <div class="col-md-9">
      <div class="justify-content-center">
        <div class="col-md-8 shadow-sm" style="margin-top:30px;">
        <?php

            $id = $_GET['id'];
            $course = "SELECT * FROM `06_course` WHERE id = '$id'";
            $run = mysqli_query($conn, $course);
            while ($data = mysqli_fetch_assoc($run)):
        ?>

        <form method="post">
            <h3 class="text-left my-3">Edit Course</h3>
                    
            <label>Course Title</label>
            <input type="text" name="title" class="form-control my-2" placeholder="Enter course title" value="<?php echo $data['course_title'] ?>" autocomplete="off" required>

            <label>Course code</label>
            <input type="text" name="code" class="form-control my-2" placeholder="Enter course code" value="<?php echo $data['course_code'] ?>" autocomplete="off" required>
            <label>Credit</label>
            <input type="text" name="credit" class="form-control my-2" placeholder="Enter course credit" value="<?php echo $data['credit'] ?>" autocomplete="off" required>

            <label>Offering  dept id </label>
            <select name="offering_dept" id="offering_dept" class="form-control my-2" required>
            <option value="" disabled selected selected="selected">Select</option>
            <?php 
            $sql = "SELECT * from 04_department WHERE status_04 = 1";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo $rows['id']; ?>"
                <?php echo ($rows['id'] ==$data['offering_deptid']) ? "selected" : ""; ?>
                >
                <?php echo $rows["dept_name" ];?>
                 </option>
                 <?php } ?>
            </select>

            <label>Receiving dept id </label>
            <select name="receiving_dept" id="receiving_dept" class="form-control my-2">
            <option value="" disabled selected selected="selected">Select</option>
            <?php 
            $sql = "SELECT * from 04_department WHERE status_04 = 1";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo $rows['id']; ?>"
                <?php echo ($rows['id'] ==$data['receiving_deptid']) ? "selected" : ""; ?>
                >
                <?php echo $rows["dept_name" ];?>
                 </option>
                 <?php } ?>
            </select>

            <label style="margin-top: 15px;">Course teacher </label>
            <select name="ctid" id="ctid" class="form-control my-2" required>
            <option value="" disabled selected selected="selected">Select</option>
            <?php 
            $sql = "SELECT * from 05_teacher WHERE deptid = '$deptId'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo $rows['id']; ?>"
                <?php echo ($rows['id'] ==$data['current_teacher_id']) ? "selected" : ""; ?>
                >
                <?php echo $rows["name" ] ;
                 ?> (<?php echo $rows["id" ] ;
                 ?>)
                 </option>
                 <?php } ?>
            </select>

            <label style="margin-top: 15px;">Semester Name</label>
            <select name="semester_name" class="form-control my-2">
              <option value="fall"
              <?php echo ("fall" ==$data['semester_name']) ? "selected" : ""; ?>
              >Fall</option>
              <option value="spring"
              <?php echo ("spring" ==$data['semester_name']) ? "selected" : ""; ?>
              >Spring</option>
              <option value="summer"
              <?php echo ("summer" ==$data['semester_name']) ? "selected" : ""; ?>
              >Summer</option>
            </select>

            <label style="margin-top: 15px;">Status</label>
            <select name="status" class="form-control my-2">
              <option value="1"
              <?php echo ("1" ==$data['status_06']) ? "selected" : ""; ?>
              >Active</option>
              <option value="0"
              <?php echo ("0" ==$data['status_06']) ? "selected" : ""; ?>
              >Deactive</option>
            </select>

            <input type="submit" name="save" class="btn bg-dark text-white" value="Update">
        <?php endwhile; ?>
          </form>
        </div>
      </div>
    </div>
</div>



 




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>
</html>  


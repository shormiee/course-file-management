<?php include('header_essential.php'); ?>
<?php
session_start();


if (isset($_POST['update'])) {
      $id = $_POST['id'];
     
    $dept_name = $_POST['dept_name'];
 $zz = $_POST['id'];
   $dept_code = $_POST['dept_code'];
   $program_code = $_POST['program_code'];
 $total_credit = $_POST['total_credit'];
  $email = $_POST['email'];
 $sts = $_POST['sts'];

include_once("includes/connection.php");
 $query = 'UPDATE 04_department set dept_name = "'.$dept_name.'" , dept_code = "'.$dept_code.'", program_code = "'.$program_code.'", total_credit = "'.$total_credit.'", email = "'.$email.'", status_04 = "'.$sts.'"  where id = "'.$zz.'"';
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

 }
 ?>
<script type="text/javascript">
			alert("Update Successfull.");
			window.location = "s_dept_list.php";
		</script>



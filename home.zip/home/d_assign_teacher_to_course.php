 <?php
  session_start();
  include_once("includes/connection.php");
  $deptId = $_SESSION['deptid'];
  $query = "SELECT * FROM 06_course WHERE offering_deptId = '$deptId'";
  $teacher = "SELECT * FROM 05_teacher WHERE deptid = '$deptId'";


   if (isset($_POST['submit'])) {

      $teacher = $_POST['teacher'];
      $course = $_POST['course'];

      $sql="UPDATE `06_course` SET `current_teacher_id`='$teacher' WHERE id='$course'";
      $res=mysqli_query($conn,$sql);

if($res){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}



      }
?>

<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

  <div class="filter-section">
  <div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

   <!--  <div class="col-auto">
   <input type="button" name="ans" value="submit" class="btn btn-dark" onclick="document.getElementById('sidebar').style.display = 'block' ;" />
  </div> -->
</div>
  </div>

  <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "d_dtwo";
    include ("./d_main_nav.php");
     ?>
</div>


 <div class="col-md-8">
      <div class="justify-content-center" style="margin-top:30px;">
        <div class="col-md-8 shadow-sm" style="margin-bottom:30px;">
          <form method="post">
            <h3 class="text-left my-3">Assign Teacher to a Course</h3>
            <div class="text-center"></div>
              <label>Choose Course</label>
              <?php if ($result = mysqli_query($conn, $query)): ?>
              <select name="course" class="form-control my-2">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <option  value="<?php echo $row['id'] ?>">  <?php echo $row["course_code"] ?> </option>
                <?php endwhile; ?>
              </select>
              <?php endif; ?>


            <label>Teacher's Name</label>
              <?php if ($t_result = mysqli_query($conn, $teacher)): ?>
              <select name="teacher" class="form-control my-2">
                <?php while ($row = mysqli_fetch_assoc($t_result)): ?>
                <option  value="<?php echo $row['id'] ?>"><?php echo $row["name"] ?> </option>
                <?php endwhile; ?>
              </select>
              <?php endif; ?>
            
          <!--   <label>Department ID</label>
              <input type="id" name="id" class="form-control my-2" placeholder="ID/Employee ID">
            <label>Password</label>
            <input type="password" name="pass" class="form-control my-2" placeholder="Enter Password"> -->

            <input type="submit" name="submit" class="btn bg-dark text-white" style="margin-bottom:30px;margin-top:20px;" value="Save">
          </form>
        </div>
      </div>
    </div>
    </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
  </body>
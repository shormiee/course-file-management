<?php
include_once('header_essential.php'); 
?>
<?php
session_start();
 include_once("includes/connection.php");
$deptId = $_SESSION['deptid'];

if (isset($_POST['save'])) {

     $course_code = $_POST['code'];
     $course_title = $_POST['title'];
     $semester_name = $_POST['semester_name'];
     $offering_dept = $_POST['offering_dept'];
     $receiving_dept = $_POST['receiving_dept'];
     $current_teacher_id = $_POST['ctid'];
     $credit = $_POST['credit'];
     $program_code = $_SESSION['program_code'];
     $current_year = $_SESSION['current_year'];
    $current_semester = $_SESSION['current_semester'];
    $semester_name = $current_semester;
    


$query = "INSERT INTO 06_course (course_code, course_title,semester_name, offering_deptid, receiving_deptid, credit, program_code, current_teacher_id, year, status_06) values
('$course_code' , '$course_title', '$current_semester', '$offering_dept', '$receiving_dept', '$credit', '$program_code', '$current_teacher_id','$current_year',1)";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}

?>

<body>
 

<div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>
 <h5 class="text-center"> <?php echo $_SESSION['name'] . ", you are accessing department admin panel" ?></h5>; 
  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
      <a href="./d_see_courses.php">
    </div>
 <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

  <?php
     $page = "d_mfour";
    include ("./d_main_nav.php");
  ?>
  </div>



  <div class="col-md-9">
      <div class="justify-content-center">
             <div class="col-md-8 shadow-sm" style="margin-top:30px;">
          <form method="post">
            <h3 class="text-left my-3">Add New Course</h3>
                    
            <label>Course Title</label>
            <input type="text" name="title" class="form-control my-2" placeholder="Enter course title" autocomplete="off" required>

            <label>Course code</label>
            <input type="text" name="code" class="form-control my-2" placeholder="Enter course code" autocomplete="off" required>


            <input type="hidden" name="semester_name" class="form-control my-2">

            <label>Credit</label>
            <input type="text" name="credit" class="form-control my-2" placeholder="Enter course credit" autocomplete="off" required>

            <label>Offering  Department</label>
            <select name="offering_dept" id="offering_dept" class="form-control my-2" required>
            <option value="" disabled selected selected="selected">Select</option>
            <?php 
            $sql = "SELECT * from 04_department WHERE status_04 = 1";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo $rows['id']; ?>">
                <?php echo $rows["dept_name" ];?>
                 </option>
                 <?php } ?>
            </select>

            <label>Receiving Department </label>
            <select name="receiving_dept" id="receiving_dept" class="form-control my-2">
            <option value="" disabled selected selected="selected">Select</option>
            <?php 
            $sql = "SELECT * from 04_department WHERE status_04 = 1";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo $rows['id']; ?>">
                <?php echo $rows["dept_name" ];?>
                 </option>
                 <?php } ?>
            </select>

            <label style="margin-top: 15px;">Course teacher </label>
            <select name="ctid" id="ctid" class="form-control my-2">
            <option value="" disabled selected selected="selected">Select</option>
            <?php 
            $sql = "SELECT * from 05_teacher WHERE deptid = '$deptId'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_assoc($result)) {
               ?>
               <option value="<?php echo
                $rows['id']; ?>">
                <?php echo $rows["name" ] ;
                 ?> 
                 </option>
                 <?php } ?>
            </select>

       

            <input type="submit" name="save" class="btn bg-dark text-white" value="save">
          </form>
        </div>
      </div>
    </div>
</div>



 




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>
</html>  


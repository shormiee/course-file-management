<?php
include_once('header_essential.php'); 
?>
<?php
session_start();
 include_once("includes/connection.php");


if (isset($_POST['save'])) {

     $dad_name = $_POST['dadname'];
     $pass = $_POST['pass'];
     $email = $_POST['email'];
     $dept_name = $_POST['dept_id'];
     $stas = $_POST['sts'];

$query = "INSERT into 02_deptadmin (name, password, email, deptid, status_02) values
('$dad_name' , '$pass', '$email', '$dept_name', $stas)";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}

?>

<body>
 <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>

  <div class="row">
   <div class="col-3 col-sm-3">

      <?php
     $page = "five"; 
    include ("./super_admin_sidenav.php");
     ?>
    
  </div>

  <div class="col-md-9">
      <div class="justify-content-center">
             <div class="col-md-8 shadow-sm" style="margin-top:30px;">
          <form method="post">
            <h3 class="text-left my-3">Add New Department Admin</h3>

           <!--   <label>Department ID</label> -->


 <select name="dept_id" id="department" class="form-control my-2" required>

<option value="" disabled selected selected="selected">Select Department</option>
<?php 
$sql = "Select * from 04_department";
$result = mysqli_query($conn, $sql);
while ($rows = mysqli_fetch_assoc($result)) {
   ?>

   <option value="<?php echo
    $rows['id']; ?>">
    <?php echo $rows["dept_name" ] ;
     ?> 
     </option>
     <?php 
 } 

?>
   </select>
           <!--    <input type="id" name="deptid" class="form-control my-2" placeholder="Enter department Unique ID"> -->


              <label>Name</label>
              <input type="name" name="dadname" class="form-control my-2" placeholder="Enter department admin's name" required>
                    
             <label>Email Address</label>
            <input type="email" name="email" class="form-control my-2" placeholder="email" autocomplete="off" required>

            <label>Set Password</label>
            <input type="password" name="pass" class="form-control my-2" autocomplete="off" required>

             <label>Status</label>
<select class="form-select  my-2" aria-label="Default select example" name="sts" required>
  <option value="" disabled selected >choose Status</option>
  <option value="1">Activate</option>
  <option value="0">Deactivate</option>
</select>

            <input type="submit" name="save" class="btn bg-dark text-white" value="save">
          </form>
        </div>
      </div>
    </div>

</div>





  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>
</html>  


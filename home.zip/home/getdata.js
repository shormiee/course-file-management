$(document).ready(function(){  
  // code to get all records from table via select box
  $("#department").change(function() { 
 
    var id = $(this).find(":selected").val();
    var dataString = 'rid='+ id;    
    $.ajax({
      url: 'getdepartment.php',
      dataType: "json",
      data: dataString,  
      cache: false,
      success: function(deptData) {
         // if(deptData) {
          $("#deptcode").val(deptData.dept_code);
          $("#prog_code").val(deptData.program_code);
          $("#t_credit").val(deptData.total_credit);
          $("#email").val(deptData.email);
          $("#sts").val(deptData.status_04);
           console.log(deptData);    
        // } 
        
      } 
    });

  }) 
});

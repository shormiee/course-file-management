<?php include('header_essential.php'); ?>
<?php
session_start();

include_once("includes/connection.php");



if (isset($_POST['save'])){
$dept_admin = $_POST['dept_admin'];
$dept = $_POST['dept'];
$sts = $_POST['sts'];

$query = "UPDATE `02_deptadmin` SET `name`='$dept_admin',`deptid`=$dept,`status_02`=$sts WHERE `name`='$dept_admin'";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}
?>

<body>

 <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>

 <!--  <div class="container"> -->
  <div class="row">
   <div class="col-3 col-sm-3">

      <?php
     $page = "one"; 
    include ("./super_admin_sidenav.php");
     ?>
    
  </div>
      
   <!--   <div class="container"> -->
    <div class="col-sm-9" style="margin-bottom:30px;">
      <div class="justify-content-center">
        <div class="col-md-8 shadow-sm" style="margin-top:30px;">
          <form method="post">
            <h3 class="text-left my-3">Assign New Dept Admin</h3>
            <div class="text-center"></div>
              <label>Choose Department</label>
         <select id="dept" name="dept" class="form-control my-2">
            <option value="0">- Select -</option>
            <?php 
            // Fetch Department
            $sql_department = "SELECT * FROM 04_department";
            $department_data = mysqli_query($conn,$sql_department);
            while($row = mysqli_fetch_assoc($department_data) ){
                $departid = $row['id'];
                $depart_name = $row['dept_name'];

                echo "<option value='".$departid."' >".$depart_name."</option>";
            }
            ?>
        </select>
            
        <label>Choose Department Admin</label>
          <select id="dept_admin" name="dept_admin" class="form-control my-2">
            <option value="0">- Select -</option>
            <?php 
            // Fetch Department
            $sql_depadmin = "SELECT * FROM 02_deptadmin";
            $dadmin_data = mysqli_query($conn,$sql_depadmin);
            while($row = mysqli_fetch_assoc($dadmin_data) ){
                $departid = $row['name'];
                $depart_name = $row['name'];

                echo "<option value='".$departid."' >".$depart_name."</option>";
            }
            ?>
        </select>
                     <label>Status</label>
<select class="form-select  my-2" aria-label="Default select example" name="sts">
  <option value="" disabled selected >Update Status</option>
  <option value="1">Activate</option>
  <option value="0">Deactivate</option>
</select>

            <input type="submit" name="save" class="btn bg-dark text-white" style="margin-bottom:30px;margin-top:20px;" value="save">
          </form>
        </div>
      </div>
    </div>

</div>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
</body>
</html>  

<?php
  session_start();
  include_once("includes/connection.php");
  $deptId = $_SESSION['deptid'];  
  $courses="SELECT * FROM `06_course` WHERE offering_deptid = '$deptId'";
?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "teacher_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>


</div>
  </div>

  <div class="row pb-5">

   <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
     <div class="sidebar d-admin-sidenav">
                <div class="nav list-group">

<a class="sidebar-link active" href="./t_my_courses.php"> <i class="bi fright bi-arrow-right-circle"></i>My Courses</a>
</div>

  </div>
</div>


<div class="col-9">
  

 <div class="col-9 col-sm-9 col-lg-8"> 

<!-- <div class="table-responsive-sm"> -->
<table class="table" style= "border: 1px solid #979696;">
  <h3 class="caption-top text-big">My Courses</h3>
  <thead class="table-dark">
    <tr>
      <th scope="col">Course Title</th>
      <th scope="col">Course-Code</th> 
      <th scope="col">Course File Detsils</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($result = mysqli_query($conn, $courses)):
      while ($row = mysqli_fetch_assoc($result)): ?>
      <tr>
        <th scope="row"><?php echo $row['course_title'] ?></th>
        <td scope="row"><?php echo $row['course_code'] ?></td>

        <td class="col-2">
   <a href="./t_all_course_file.php?course=<?php echo $row['id'] ?>"><button class="btn btn-sm bg-dark text-white status">Upload course Files
          </button></a>
        </td>
      </tr>
    <?php endwhile; endif; ?>
  </tbody>
</table>
</div>
 </div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


</html>
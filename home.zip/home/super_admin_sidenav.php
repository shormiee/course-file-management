
   <div class="sidebar d-admin-sidenav">
        <div class="nav list-group">


 <a class="sidebar-link <?php if ($page == "three") { echo "active";}?>" href="./s_create_dept.php"> <i class="bi fright bi-arrow-right-circle"></i> Create New Dept</a>


     <a class="sidebar-link <?php if ($page == "five") { echo "active";}?>" href="./s_add_dept_admin.php"><i class="bi fright bi-arrow-right-circle"></i>Add Dept Admin</a>
        	
	<a class="sidebar-link <?php if ($page == "one") { echo "active";}?>" href="./s_assign_dept_admin.php"><i class="bi fright bi-arrow-right-circle"></i>Assign Dept Admin</a>

  	<a class="sidebar-link <?php if ($page == "two") { echo "active";}?>" href="./s_dept_list.php"><i class="bi fright bi-arrow-right-circle"> </i>See Dept List</a>

      

     	<!-- <a class="sidebar-link <?php if ($page == "four") { echo "active";}?>" href="./s_update_dept.php"><i class="bi fright bi-arrow-right-circle"></i>Update Department</a> -->

     	<a class="sidebar-link <?php if ($page == "six") { echo "active";}?>" href="./s_settings.php"><i class="bi fright bi-arrow-right-circle"></i>Settings</a>



</div>
</div>

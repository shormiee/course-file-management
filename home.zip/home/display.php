<?php
session_start();
  include_once("includes/connection.php");
  ?>



  <!DOCTYPE html>
  <html>
  <head>
  	<title>display</title>
  </head>
  <body>
  
 <div class="row">

 	<h3> Download course content</h3>
 	<table>
 		<tbody>
 			
 			<td>
 				
 			</td>
 		</tbody>
 	</table>
 	<?php 
$sql = "SELECT * from test";
$query=mysqli_query($conn,$sql);

while ($info=mysqli_fetch_array($query)) {

	?>
	<a href="new.pdf"> file 
<iframe src="test_pdf/<?php echo $info['file']; ?>" style="width: 10%;height: 10%;border: none;">
</iframe>



</a>

<?php
}


?>


 </div>
  </body>
  </html>
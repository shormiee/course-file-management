-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2022 at 06:58 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cfms`
--

-- --------------------------------------------------------

--
-- Table structure for table `01_superadmin`
--

CREATE TABLE `01_superadmin` (
  `id` bigint(100) NOT NULL,
  `name` char(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status_01` bit(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `01_superadmin`
--

INSERT INTO `01_superadmin` (`id`, `name`, `password`, `email`, `status_01`) VALUES
(1, 'abc', '123', 'abc@sub.edu.bd', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `02_deptadmin`
--

CREATE TABLE `02_deptadmin` (
  `id` bigint(100) NOT NULL,
  `name` char(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `deptid` bigint(100) NOT NULL,
  `status_02` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `03_student`
--

CREATE TABLE `03_student` (
  `id` bigint(100) NOT NULL,
  `deptid` bigint(100) NOT NULL,
  `name` char(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status_03` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `04_department`
--

CREATE TABLE `04_department` (
  `id` bigint(100) NOT NULL,
  `dept_name` char(100) NOT NULL,
  `dept_code` char(100) NOT NULL,
  `total_credit` float NOT NULL,
  `program_code` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status_04` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `05_teacher`
--

CREATE TABLE `05_teacher` (
  `id` bigint(100) NOT NULL,
  `deptid` bigint(100) NOT NULL,
  `name` char(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status_05` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `06_course`
--

CREATE TABLE `06_course` (
  `id` bigint(100) NOT NULL,
  `course_code` varchar(100) NOT NULL,
  `course_title` varchar(100) NOT NULL,
  `offering_deptid` bigint(100) NOT NULL,
  `receiving_deptid` bigint(100) NOT NULL,
  `credit` float NOT NULL,
  `current_teacher_id` bigint(100) DEFAULT NULL,
  `semester_name` char(50) DEFAULT NULL,
  `program_code` varchar(100) NOT NULL,
  `year` year(4) DEFAULT NULL,
  `status_06` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `07_course_exam`
--

CREATE TABLE `07_course_exam` (
  `id` bigint(20) NOT NULL,
  `exam_name` varchar(100) NOT NULL,
  `question_paper` varchar(100) NOT NULL,
  `best_ans_script` varchar(100) NOT NULL,
  `avg_ans_script` varchar(100) NOT NULL,
  `marginal_ans_script` varchar(100) NOT NULL,
  `status_07` bit(1) NOT NULL,
  `course_id` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `08_course_file`
--

CREATE TABLE `08_course_file` (
  `file_id` bigint(20) NOT NULL,
  `prerequisite` varchar(100) DEFAULT NULL,
  `course_outline` varchar(256) DEFAULT NULL,
  `lecture_content_link` varchar(256) DEFAULT NULL,
  `course_id` bigint(100) NOT NULL,
  `final_marksheet` varchar(100) DEFAULT NULL,
  `viva_rubrics` varchar(100) DEFAULT NULL,
  `presentation_rubrics` varchar(100) DEFAULT NULL,
  `assignment_rubrics` varchar(100) DEFAULT NULL,
  `status_08` bit(1) DEFAULT NULL,
  `text_book_ref` varchar(100) DEFAULT NULL,
  `attendance_pdf` varchar(100) DEFAULT NULL,
  `course_outcome` varchar(100) DEFAULT NULL,
  `assessment_tools` varchar(100) DEFAULT NULL,
  `grading_policy` varchar(100) DEFAULT NULL,
  `result_pdf` varchar(100) DEFAULT NULL,
  `lab_reports` varchar(100) DEFAULT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `09_settings`
--

CREATE TABLE `09_settings` (
  `id` bigint(20) NOT NULL,
  `current_year` year(4) NOT NULL,
  `current_semester` char(50) NOT NULL,
  `status_09` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `01_superadmin`
--
ALTER TABLE `01_superadmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `02_deptadmin`
--
ALTER TABLE `02_deptadmin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deptid` (`deptid`);

--
-- Indexes for table `03_student`
--
ALTER TABLE `03_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deptid` (`deptid`);

--
-- Indexes for table `04_department`
--
ALTER TABLE `04_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `05_teacher`
--
ALTER TABLE `05_teacher`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deptid` (`deptid`);

--
-- Indexes for table `06_course`
--
ALTER TABLE `06_course`
  ADD PRIMARY KEY (`id`),
  ADD KEY `current_teacher_id` (`current_teacher_id`),
  ADD KEY `offering_deptid` (`offering_deptid`),
  ADD KEY `receiving_deptid` (`receiving_deptid`);

--
-- Indexes for table `07_course_exam`
--
ALTER TABLE `07_course_exam`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `08_course_file`
--
ALTER TABLE `08_course_file`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `09_settings`
--
ALTER TABLE `09_settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `01_superadmin`
--
ALTER TABLE `01_superadmin`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `02_deptadmin`
--
ALTER TABLE `02_deptadmin`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `03_student`
--
ALTER TABLE `03_student`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `04_department`
--
ALTER TABLE `04_department`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `05_teacher`
--
ALTER TABLE `05_teacher`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `06_course`
--
ALTER TABLE `06_course`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `07_course_exam`
--
ALTER TABLE `07_course_exam`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `08_course_file`
--
ALTER TABLE `08_course_file`
  MODIFY `file_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `09_settings`
--
ALTER TABLE `09_settings`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `02_deptadmin`
--
ALTER TABLE `02_deptadmin`
  ADD CONSTRAINT `02_deptadmin_ibfk_1` FOREIGN KEY (`deptid`) REFERENCES `04_department` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

 <?php
 include('header_essential.php'); 
 ?>
<?php 
session_start();
include_once("includes/connection.php");

$deptId = $_SESSION['deptid'];
//echo $deptId;

if (isset($_POST['save'])) {
    $deptid = $_POST['deptid'];
     $tname = $_POST['name'];
     $pass = $_POST['pass'];
     $email = $_POST['email'];
     $status = $_POST['stats'];

$query = "INSERT into 05_teacher (deptid, name, password, email,  status_05) values
('$deptid', '$tname' , '$pass', '$email', $status)";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}

?>


<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

  
</div>
  </div>

  <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "d_two";
    include ("./d_main_nav.php");
     ?>
</div>


 <div class="col-md-8">
      <div class="justify-content-center" style="margin-top:30px;">
        <div class="col-md-8 shadow-sm" style="margin-bottom:30px;">
          <form method="post" action="d_add_teacher.php">
            <h3 class="text-left my-3">Add New Teacher</h3>
            <div class="text-center"></div>

  <!--  <select name="dept_id" id="department" class="form-control my-2">

<option value="" disabled selected selected="selected">Select Department</option>
   <option value=" <?php $deptId ;?>"></option>
   
     </option>

   </select> -->

 <input type="hidden" name="deptid" class="form-control my-2"  autocomplete="off" value="<?php echo $deptId ;?>">


              <label>Teacher's Name</label>
            <input type="name" name="name" class="form-control my-2"  autocomplete="off">



 <label>Email Address</label>
            <input type="email" name="email" class="form-control my-2" placeholder="email" autocomplete="off">

 <label>Set Password</label>
      
 <input type="text" name="pass" class="form-control my-2" autocomplete="off">

    <label>Status</label>
<select class="form-select  my-2" aria-label="Default select example" name="stats">
  <option value="" disabled selected >choose Status</option>
  <option value="1">Activate</option>
  <option value="0">Deactivate</option>
</select>

<input type="submit" name="save" class="btn bg-dark text-white" value="save">
          </form>
        </div>
      </div>
    </div>
    </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
  </body>
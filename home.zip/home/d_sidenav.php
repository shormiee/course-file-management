
<div class="sidebar d-admin-sidenav my-5">
                <div class="nav list-group">

<a class="sidebar-link <?php if ($page == "d_prereq") { echo "active";}?>" href="./d_all_course_file.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Prerequisite</a>

<a class="sidebar-link  <?php if ($page == "d_coutline") { echo "active";}?>" href="./d_course_outline.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Course Outline</a> 

<a class="sidebar-link <?php if ($page == "dlink") { echo "active";}?> " href="./d_course_content_link.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Course Content Link</a>

<a class="sidebar-link <?php if ($page == "dbookref") { echo "active";}?> " href="./d_txt_book_ref.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i> Text Book Reference</a>
<!-- 
  <div class="list-group-item bg-dark"> -->

<a href="#submenu3" data-bs-toggle="collapse" class="sidebar-link align-middle dropdown-toggle">
  <i class="bi fright bi-grid"></i>
  <span class="ms-1 d-none d-sm-inline"></span>Exams
</a>
  <div class="collapse nav flex-column ms-1" id="submenu3" data-bs-parent="#menu">
    <a href="#submenu4" data-bs-toggle="collapse" class="sidebar-link align-middle dropdown-toggle">Quiz/CT</a>
    <div class="collapse nav flex-column ms-1" id="submenu4" data-bs-parent="#menuchild"> 
      <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "dctq") { echo "active";}?>" href="./d_ct_question.php?id=<?php echo $_SESSION['courseid']; ?>" >Question</a>
      <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "dct1") { echo "active";}?>" href="./d_ct_best_ans.php?id=<?php echo $_SESSION['courseid']; ?>" >Answer Script</a>
              <!--    <a class="mega-sub-sidebar-link mx-0 px-0  " href="./d_ct_avg_ans.php" >Average Answer Script</a>
                <a class="mega-sub-sidebar-link mx-0 px-0" href="./d_ct_marginal_ans.php" >Marginal Answer Script</a> -->
    </div> 
                        <a href="#submenu5" data-bs-toggle="collapse" class="sidebar-link px-0 align-middle dropdown-toggle">Mid Term</a>

                        <div class="collapse nav flex-column ms-1" id="submenu5" data-bs-parent="#menuchild">

                  <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "dmid") { echo "active";}?>" href="./d_mid_quest.php?id=<?php echo $_SESSION['courseid']; ?>" >Question</a>
      <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "dmidans") { echo "active";}?>" href="./d_mid_ans.php?id=<?php echo $_SESSION['courseid']; ?>" >Answer Script</a>
            
 </div> 

                         <a href="#submenu6" data-bs-toggle="collapse" class="sidebar-link px-0 align-middle dropdown-toggle">Final</a>
                             <div class="collapse nav flex-column ms-1" id="submenu6" data-bs-parent="#menuchild"> 
                      <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "dfinal") { echo "active";}?>" href="./d_final_quest.php?id=<?php echo $_SESSION['courseid']; ?>" >Question</a>
      <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "dfinalans") { echo "active";}?>" href="./d_final_ans.php?id=<?php echo $_SESSION['courseid']; ?>" >Answer Script</a>
                      
         </div> 


           <!--                     <a href="#submenu7" data-bs-toggle="collapse" class="sidebar-link px-0 align-middle dropdown-toggle"></span>Assignment</a>
                                <div class="collapse nav flex-column ms-1" id="submenu7" data-bs-parent="#menuchild"> 
                    <a class="mega-sub-sidebar-link mx-0 px-0" href="#">Question</a>
                   mega-sub-sidebar-link mx-0 px-0" href="#">Best Answer Script</a>
                  <a class="mega-sub-sidebar-link mx-0 px-0" href="#">Average Answer Script</a>
              <a class="mega-sub-sidebar-link mx-0 px-0" href="#">Marginal Answer Script</a>
</div>  -->
                                                                                            
     </div> <!-- exam papers ends here     -->

    <a class="sidebar-link  <?php if ($page == "asr") { echo "active";}?>  " href="./d_assignment_rubrics.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Assignment Rubrics</a> 

    <a class="sidebar-link  <?php if ($page == "prs") { echo "active";}?>   " href="./d_presentationr.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Presentation Rubrics</a>

    <a class="sidebar-link  <?php if ($page == "vvr") { echo "active";}?>  " href="./d_viva.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Viva Rubrics</a>
    
    <a class="sidebar-link <?php if ($page == "lbr") { echo "active";}?>  " href="./d_lab_report.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Lab Report</a>
    
    <a class="sidebar-link  <?php if ($page == "attd") { echo "active";}?> " href="./d_attendance.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Attendance</a>
    
    <a class="sidebar-link  <?php if ($page == "asst") { echo "active";}?>  " href="./d_assessment.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Assessment Tools</a> 
    
    <a class="sidebar-link  <?php if ($page == "com") { echo "active";}?> " href="./d_course_outcome.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Course Outcome</a>
    
    <a class="sidebar-link  <?php if ($page == "gdp") { echo "active";}?>  " href="./d_grading.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"></i>Grading Policy</a>
    
    <a class="sidebar-link  <?php if ($page == "crt") { echo "active";}?>" href="./d_current_teacher.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"> </i>Current Teacher</a>
    
    <a class="sidebar-link  <?php if ($page == "fmt") { echo "active";}?> " href="./d_final_marksheet.php?id=<?php echo $_SESSION['courseid']; ?>"><i class="bi fright bi-arrow-right-circle"></i>Final Marksheet</a>
    
    <a class="sidebar-link  <?php if ($page == "rsl") { echo "active";}?> " href="./d_result.php?id=<?php echo $_SESSION['courseid']; ?>"> <i class="bi fright bi-arrow-right-circle"> </i>Result PDF</a>
  </div>
</div>

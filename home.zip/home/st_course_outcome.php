<?php
  session_start();
  include_once("includes/connection.php");

  function download($file)
  {
    if(!$file)
    {
       // File doesn't exist, output error
      die('file not found');
    }
    else
    {
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename='.basename($file));
      header('Content-Transfer-Encoding: binary');
      header('Expires: 0');
      header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
      header('Pragma: public');
      header('Content-Length: ' . filesize($file));
      ob_clean();
      flush();
      readfile($file);
      exit;
    }
  }

  if(isset($_GET['click'])){
      download($_GET['click']);
    }
?>


<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "student_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

</div>
  </div>


 <div class="row">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "com";
    include ("./st_sidenav.php");
     ?>
</div>

<div class="col-md-5 shadow" style="margin-top: 30px; height: 300px;">
<table class="table">
  <thead>
    <tr>
      <th scope="col">UPLOADED BY</th>
       <th scope="col">Course Outcome</th>
    </tr>
  </thead>
  
  <tbody>
  <?php
    $course = $_SESSION['courseid'];
    $year = $_SESSION['current_year'];
    $semester = $_SESSION['current_semester'];
    $course_file = "SELECT * FROM 08_course_file,06_course WHERE course_id = '$course' AND 08_course_file.course_id = 06_course.id AND 06_course.year = '$year' AND 06_course.semester_name = '$semester'";
    if ($result = mysqli_query($conn, $course_file)):
    while ($row = mysqli_fetch_assoc($result)):
  ?>
    <tr>
      <td>
        <?php 
          $id = $row['teacher_id'];
          $teacher = "SELECT name FROM `05_teacher` WHERE id = '$id'";
          if ($result1 = mysqli_query($conn, $teacher)){
          $row1 = mysqli_fetch_assoc($result1);
          echo $row1['name'];
        }
       ?>
      </td>
      <td>
        <button onclick="document.location.href='d_course_outcome.php?click=<?php echo $row['course_outcome'] ?>'" class="btn"><i class="bi bi-download"></i>
          <?php 
            $file=explode("/", $row['course_outcome']);
            $file_name = strtolower(end($file));
            echo $file_name;
          ?>
        </button>
      </td>
    </tr>
   <?php endwhile; endif; ?>
  </tbody>
</table>
</div>

</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>
</html>
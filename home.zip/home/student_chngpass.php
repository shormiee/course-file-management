<?php include('header_essential.php');
 ?>
<?php
session_start();
include_once("includes/connection.php");

if (isset($_POST['save']) ) {

    $opwd = $_POST['opwd'];
    $id = $_SESSION['id'];
 $newpass = $_POST['npwd'];
    $sql=mysqli_query($conn,"SELECT password FROM 02_deptadmin where password='$opwd' && id = '$id'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
 $conn=mysqli_query($conn,"update 02_deptadmin set password = '$newpass' where id='$id'");
$_SESSION['msg1']="Password Changed Successfully !!";
}
else
{
$_SESSION['msg1']="Old Password does not match !!";
}
}
?>


<body>
	 <div class="menu">
  <?php include "student_topmenu.php"; ?>
 </div>
 <div class="container">
<div class="col-md-12">
      <div class="justify-content-center">

      
     
             <div class="col-md-10 shadow-sm" style="margin-top:30px;">	
  <p><?php echo $_SESSION['msg1'];?><?php echo $_SESSION['msg1']="";?></p>
   <form name="chngpwd" method="post" action="" align="center">
Current Password:<br>
<input type="password" name="opwd"><span id="opwd" class="required"></span>
<br>
New Password:<br>
<input type="password" name="npwd"><span id="npwd" class="required"></span>
<br>
Confirm Password:<br>
<input type="password" name="cpwd"><span id="cpwd" class="required"></span>
<br><br>
<input name="save" type="submit" value="change password">
</form>

 </div>
</div>
</div>
</div>

<script type="text/javascript">
function valid()
{
if(document.chngpwd.opwd.value=="")
{
alert("Old Password Filed is Empty !!");
document.chngpwd.opwd.focus();
return false;
}
else if(document.chngpwd.npwd.value=="")
{
alert("New Password Filed is Empty !!");
document.chngpwd.npwd.focus();
return false;
}
else if(document.chngpwd.cpwd.value=="")
{
alert("Confirm Password Filed is Empty !!");
document.chngpwd.cpwd.focus();
return false;
}
else if(document.chngpwd.npwd.value!= document.chngpwd.cpwd.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.chngpwd.cpwd.focus();
return false;
}
return true;
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
</body>

  <?php 
   $page = "d_one";
   ?>

 <div class="col-10 col-sm-10 col-lg-8"> 

<!-- <div class="table-responsive-sm"> -->
<table class="table" style= "border: 1px solid #979696;">
  <caption class="caption-top">Course List</caption>
  <thead class="table-dark">
    <tr>
      <th scope="col">Course Title</th>
            <th scope="col">Course-Code</th> 
            <th scope="col">Current Teacher ID</th>
           <th scope="col">Actions</th> 
            <th scope="col">Status</th> 
    </tr>
  </thead>
  <tbody>
      <tr>
      <th scope="row">Microprocessor</th>
              <td scope="row">Cse-400</td>


<td scope="row">EMP202156a</td>

     <td class="col-2">
      <button class="me-2 btn btn-lg text-dark edit-button"><i class="bi bi-pencil-square"></i>
        </button>
          <button class="me-2 btn btn-lg text-dark delete-button"><i class="bi bi-trash"></i>
          </button>
      </td>
       <td class="col-2">
       <button class="btn btn-sm bg-dark text-white status"><i class="bi bi-x-circle"></i>
Deactivate
        </button>
      </td>
     
    </tr>
    <tr>
      <th scope="row">Project & Thesis</th>
              <td scope="row">Cse-400</td>
              <td scope="row">EMPc202156b</td>
     <td class="col-2">
      <button class="me-2 btn btn-lg text-dark edit-button"><i class="bi bi-pencil-square"></i>
        </button>
          <button class="me-2 btn btn-lg text-dark delete-button"><i class="bi bi-trash"></i>
          </button>
      </td>
       <td class="col-2">
      <button class="btn btn-sm bg-dark text-white status"><i class="bi bi-check-square"></i>Activated
        </button>
      </td>
    </tr>

 <tr>
      <th scope="row">Computer Network</th>
              <td scope="row">Cse-400</td>
              <td scope="row">EMP202156c</td>
     <td class="col-2">
      <button class="me-2 btn btn-lg text-dark edit-button"><i class="bi bi-pencil-square"></i>
        </button>
          <button class="me-2 btn btn-lg text-dark delete-button"><i class="bi bi-trash"></i>
          </button>
      </td>
       <td class="col-2">
       <button class="btn btn-sm bg-dark text-white status"><i class="bi bi-x-circle"></i>
Deactivate
        </button>
      </td>
     
    </tr>
     <tr>
      <th scope="row">Microprocessor</th>
              <td scope="row">Cse-400</td>
              <td scope="row">EMP-202156a</td>
     <td class="col-2">
      <button class="me-2 btn btn-lg text-dark edit-button"><i class="bi bi-pencil-square"></i>
        </button>
          <button class="me-2 btn btn-lg text-dark delete-button"><i class="bi bi-trash"></i>
          </button>
      </td>
       <td class="col-2">
       <button class="btn btn-sm bg-dark text-white status"><i class="bi bi-x-circle"></i>
Deactivate
        </button>
      </td>
     
    </tr>
     <tr>
      <th scope="row">Project & Thesis</th>
              <td scope="row">Cse-400</td>
              <td scope="row">EMP-202156a</td>
     <td class="col-2">
      <button class="me-2 btn btn-lg text-dark edit-button"><i class="bi bi-pencil-square"></i>
        </button>
          <button class="me-2 btn btn-lg text-dark delete-button"><i class="bi bi-trash"></i>
          </button>
      </td>
       <td class="col-2">
       <button class="btn btn-sm bg-dark text-white status"><i class="bi bi-x-circle"></i>
Deactivate
        </button>
      </td>
     
    </tr>
      <tr>
      <th scope="row">Microprocessor</th>
              <td scope="row">Cse-400</td>
              <td scope="row">EMP2202156a</td>
     <td class="col-2">
      <button class="me-2 btn btn-lg text-dark edit-button"><i class="bi bi-pencil-square"></i>
        </button>
          <button class="me-2 btn btn-lg text-dark delete-button"><i class="bi bi-trash"></i>
          </button>
      </td>
       <td class="col-2">
       <button class="btn btn-sm bg-dark text-white status"><i class="bi bi-x-circle"></i>
Deactivate
        </button>
      </td>
     
    </tr>

 
  </tbody>
</table>
<!-- </div> -->

</div>
<?php
  session_start();
  include_once("includes/connection.php");

?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
</head>
<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

<div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
   <!-- <input type="button" name="ans" value="submit" class="btn btn-dark" onclick="document.getElementById('sidebar').style.display = 'block' ;" /> -->
  </div>
</div>
</div>

  <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

       <?php
     $page = "d_3";
    include ("./d_main_nav.php");
     ?>
  </div>


  <div class="col-md-9">
  

 <div class="col-10 col-sm-10 col-lg-8"> 

<!-- <div class="table-responsive-sm"> -->
<table class="table" style= "border: 1px solid #979696;">
  <caption class="caption-top">Teacher's List</caption>
  <thead class="table-dark">
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Email</th> 
      <th scope="col">Department</th> 
      <th scope="col">Status</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <?php 
    $deptId = $_SESSION['deptid'];
    $sql = "SELECT * FROM `05_teacher` WHERE deptid = '$deptId'"

   ?>
  <tbody>
    <?php if ($result = mysqli_query($conn, $sql)):
      while ($row = mysqli_fetch_assoc($result)): ?>
      <tr>
      <th scope="row"><?php echo $row['name'] ?></th>
      <td scope="row"><?php echo $row['email'] ?></td>
      <td scope="row">
        <?php 
            $did = $row['deptid'];
            $sql = "SELECT * from 04_department WHERE id = '$did'";
            $result = mysqli_query($conn, $sql);
            $d = mysqli_fetch_assoc($result);
            echo $d['dept_name'];
        ?>
      </td>
      <td scope="row"><?php echo ($row['status_05']==1) ? 'Active': 'Deactive' ?></td>


      <td class="col-2">
        <button class="me-2 btn btn-lg text-dark edit-button">
          <a class="btn btn-lg" href="d_teacher_edit.php?id=<?php echo $row['id'] ?>"><i class="bi bi-pencil-square"></i></a>
        </button>
        <!-- </button> -->
      </td>
    </tr>
  <?php endwhile; endif; ?>
  </tbody>
</table>
</div>
 </div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


</html>
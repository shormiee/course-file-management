
<div class="sidebar d-admin-sidenav">
  <div class="nav list-group">


<a class="sidebar-link <?php if ($page == "d_two") { echo "active";}?>" href="./d_add_teacher.php"> <i class="bi fright bi-arrow-right-circle"></i>Manage Teachers </a>
 <a class="sidebar-link <?php if ($page == "d_mfour") { echo "active";}?>" href="./course_manage.php"> <i class="bi fright bi-arrow-right-circle"></i>Manage courses </a>
   <a class="sidebar-link <?php if ($page == "d_three") { echo "active";}?>" href="./d_manage_students.php"> <i class="bi fright bi-arrow-right-circle"></i>Manage Students </a>

 <a class="sidebar-link <?php if ($page == "d_3") { echo "active";}?>" href="./d_see_teacher.php"> <i class="bi fright bi-arrow-right-circle"></i>See Teachers</a>

    <a class="sidebar-link <?php if ($page == "d_one") { echo "active";}?>" href="./d_see_courses.php"> <i class="bi fright bi-arrow-right-circle"></i>See Courses</a> 
   

    <a class="sidebar-link <?php if ($page == "d_2") { echo "active";}?>" href="./d_see_student.php"> <i class="bi fright bi-arrow-right-circle"></i>See Students</a> 
  

   
   <!--  <a class="sidebar-link <?php if ($page == "d_dtwo") { echo "active";}?>" href="./d_assign_teacher_to_course.php"> <i class="bi fright bi-arrow-right-circle"></i>Assign Teacher to course </a> -->
    

  </div>
</div>

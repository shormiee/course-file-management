<?php
session_start();
  include_once("includes/connection.php");

     if (isset($_POST['submit'])) {
          $pdf=$_FILES['filename']['name'];
          $pdf_type=$_FILES['filename']['type'];
          $pdf_size=$_FILES['filename']['size'];
          $pdf_tem_loc=$_FILES['filename']['tmp_name'];
          $pdf_store="test_pdf/".$pdf;

          move_uploaded_file($pdf_tem_loc,$pdf_store);
       
          $sql="INSERT INTO test(file) values('$pdf')";
          $query=mysqli_query($conn,$sql);
        }
?>


<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  




 <div class="row pb-5">




  
  <form action="" method="post" enctype="multipart/form-data">
    <h3>Upload Prerequisite course List:</h3>
    <div class="custom-file mb-3">
      <input type="file" class="custom-file-input" id="customFile" name="filename" required="">
    </div>
   <div class="input-group mb-3">
    <input type="text" name="name" placeholder="File Name" required>
    
   </div>
  
  
    <div class="mt-3">
      <button type="submit" name="submit" class="btn text-white bg-dark">Upload</button>
    </div>





</form>            
    




</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


</html>
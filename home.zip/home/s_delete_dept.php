<?php include('header_essential.php'); ?>
<?php
session_start();

include_once("includes/connection.php");
 if (isset($_GET['id'])) {
    
     $zz = $_GET['id'];
   
 $query = 'DELETE from 04_department where id = "'.$zz.'"';
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

}
 ?>
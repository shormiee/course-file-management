<?php include('header_essential.php'); ?>
<?php
session_start();

include_once("includes/connection.php");



if (isset($_POST['save'])){
$dept_admin = $_POST['dept_admin'];
$dept = $_POST['dept'];
$sts = $_POST['sts'];

$query = "UPDATE `02_deptadmin` SET `name`='$dept_admin',`deptid`=$dept,`status_02`=$sts WHERE `name`='$dept_admin'";
 $query_run = mysqli_query($conn, $query);

if($query_run){
   $_SESSION['status'] =  "Records inserted successfully.";

} else{
  $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
}
}
?>

<body>

 <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>

 <!--  <div class="container"> -->
  <div class="row">
   <div class="col-3 col-sm-3">

      <?php
     $page = "one"; 
    include ("./super_admin_sidenav.php");
     ?>
    
  </div>
      
   <!--   <div class="container"> -->
    <div class="col-sm-9" style="margin-bottom:30px;">
      <div class="justify-content-center">
        <div class="col-md-8 shadow-sm" style="margin-top:30px;">
          <form method="post">
            <h3 class="text-left my-3">Assign New Dept Admin</h3>
            <div class="text-center"></div>
             
    
                     <label>Status</label>
<select class="form-select  my-2" aria-label="Default select example" name="sts">
  <option value="" disabled selected >Update Status</option>
  <option value="1">Activate</option>
  <option value="0">Deactivate</option>
</select>

            <input type="submit" name="save" class="btn bg-dark text-white" style="margin-bottom:30px;margin-top:20px;" value="save">
          </form>
        </div>
      </div>
    </div>

</div>
<!-- </div> -->
<!-- <div class="col-md-9" style="margin: 0 auto;">  
<div class=" justify-content-center"> 
<div class="table-responsive-sm"> -->
<!-- <table class="table table caption-top"style= "border: 1px solid #979696;">
  <caption>List of Department Admin</caption>
  <thead class="table-dark">

    <tr>
      <th scope="col">Name</th>
      <th scope="col">Department</th>
           <th scope="col">Actions</th> 
           <th scope="col">Status</th> 
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Mr Khan</th>
      <td class="col-md-3">CSE</td>

     <td class="col-md-3">
      <button class="me-2 btn btn-small btn-dark edit-button"> Edit
        </button>
          <button class="me-2 btn btn-small btn-dark delete-button"> Delete
          </button>
      </td>
      <td class="col-md-3"><button type="button" class="btn btn-small btn-primary" >Activate</button>
<button type="button" class="btn btn-secondary btn-small" disabled>Deactivated</button></td>
     
    </tr>
    <tr>
      <th scope="row">MD: Chowdhury</th>
      <td>LAW</td>
    <td class="col-md-3">
      <button class="me-2 btn btn-small btn-dark edit-button"> Edit
        </button>
          <button class="me-2 btn btn-small btn-dark delete-button"> Delete
          </button>
      </td>
      <td class="col-md-3"><button type="button" class="btn btn-small btn-primary" disabled>Activate</button>
<button type="button" class="btn btn-secondary btn-small">Deactivate</button></td>

  
    </tr>
    <tr>
      <th scope="row">MD: Ehsan</th>
      <td>Pharmacy</td>
    <td class="col-md-3">
      <button class="me-2 btn btn-small btn-dark edit-button"> Edit
        </button>
          <button class="me-2 btn btn-small btn-dark delete-button"> Delete
          </button>
      </td>
      <td class="col-md-3"><button type="button" class="btn btn-small btn-primary" >Activate</button>
<button type="button" class="btn btn-secondary btn-small" disabled>Deactivated</button></td>

 
    </tr>
  </tbody>
</table> -->
<!-- </div> -->

</div>
</div> -->
<!-- </div> -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
</body>
</html>  

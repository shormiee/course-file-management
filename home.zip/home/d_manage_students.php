<?php
  session_start();
  include_once("includes/connection.php");
  $deptId = $_SESSION['deptid'];

  if (isset($_POST['submit'])) {

      $name = $_POST['name'];  
      $password = $_POST['pass'];
      $email = $_POST['email'];

      $sql="INSERT INTO 03_student(name,password,deptid,email) values('$name','$password','$deptId','$email')";
      $query=mysqli_query($conn,$sql);
    }
  ?>

<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

   <!--  <div class="col-auto">
   <input type="button" name="ans" value="submit" class="btn btn-dark" onclick="document.getElementById('sidebar').style.display = 'block' ;" />
  </div> -->
</div>
  </div>

  <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "d_three";
    include ("./d_main_nav.php");
     ?>
</div>


 <div class="col-md-8">
      <div class="justify-content-center" style="margin-top:30px;">
        <div class="col-md-8 shadow-sm" style="margin-bottom:30px;">
          <form method="post">
            <h3 class="text-left my-3">Add New Student</h3>
            <div class="text-center"></div>
              <label>Student Id</label>
              <input type="text" name="name" placeholder="Enter student name" class="form-control my-2" required>
            
              <label>Student's password</label>
              <input type="password" name="pass" placeholder="Enter a password" class="form-control my-2" required>

              <label>Student's Email</label>
              <input type="email" name="email" placeholder="Enter student email" class="form-control my-2">


            <input type="submit" name="submit" class="btn bg-dark text-white" style="margin-bottom:30px;margin-top:20px;" value="save">
          </form>
        </div>
      </div>
    </div>
    </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
  </body>
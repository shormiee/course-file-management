<?php
session_start();

?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
</head>
<body>
  <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>


 <h5 class="text-center"> <?php echo $_SESSION['name'] . ", welcome to super admin panel" ?></h5>; 

  <div class="row">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

       <?php
     $page = "";
    include ("./super_admin_sidenav.php");
     ?>
  </div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
</body>


</html>

<div class="sidebar d-admin-sidenav">
    <div class="nav list-group">

        <a class="sidebar-link <?php if ($page == "tone") { echo "active";}?>" href="./t_all_course_file.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Prerequisite</a>

        <a class="sidebar-link  <?php if ($page == "ttwo") { echo "active";}?>" href="./t_course_outline.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Course Outline</a> 

        <a class="sidebar-link <?php if ($page == "tthree") { echo "active";}?> " href="./t_course_content_link.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Course Content Link</a>

        <a class="sidebar-link <?php if ($page == "tfour") { echo "active";}?> " href="./t_txt_book_ref.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i> Text Book Reference</a>
        <!-- <div class="list-group-item bg-dark"> -->
        <a href="#submenu3" data-bs-toggle="collapse" class="sidebar-link align-middle dropdown-toggle">
           <i class="bi fright bi-grid"></i>
           <span class="ms-1 d-none d-sm-inline"></span>Exams
        </a>
        <div class="collapse nav flex-column ms-1" id="submenu3" data-bs-parent="#menu">

            <a href="#submenu4" data-bs-toggle="collapse" class="sidebar-link align-middle dropdown-toggle"></span>Quiz/CT </a>
            <div class="collapse nav flex-column ms-1" id="submenu4" data-bs-parent="#menuchild"> 
                <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "tctq") { echo "active";}?>" href="./t_ct_question.php?course=<?php echo $_SESSION['courseid'] ?>">Question & Ans Script</a>               
            </div> 


            <a href="#submenu5" data-bs-toggle="collapse" class="sidebar-link px-0 align-middle dropdown-toggle"></span>Mid Term</a>

            <div class="collapse nav flex-column ms-1" id="submenu5" data-bs-parent="#menuchild"> 
                <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "mid") { echo "active";}?> " href="./t_mid_exam_files.php?course=<?php echo $_SESSION['courseid'] ?>" >Question & Ans Script</a>   
            </div> 
            <a href="#submenu6" data-bs-toggle="collapse" class="sidebar-link px-0 align-middle dropdown-toggle"></span>Final Exam</a>

            <div class="collapse nav flex-column ms-1" id="submenu6" data-bs-parent="#menuchild"> 
                <a class="mega-sub-sidebar-link mx-0 px-0 <?php if ($page == "final") { echo "active";}?> " href="./t_final_exam.php?course=<?php echo $_SESSION['courseid'] ?>" >Question & Ans Script</a>      
            </div> 

                                                                             
        </div> <!-- exam papers ends here     -->


        <a class="sidebar-link <?php if ($page == "six") { echo "active";}?> "href=./t_assignment.php?course=<?php echo $_SESSION['courseid'] ?>> <i class="bi fright bi-arrow-right-circle"></i>Assignment Rubrics</a> 

        <a class="sidebar-link <?php if ($page == "seven") { echo "active";}?> " href="./t_presentation_rubrics.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Presentation Rubrics</a> 
                    
        <a class="sidebar-link <?php if ($page == "eight") { echo "active";}?> " href="./t_viva_rubrics.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Viva Rubrics</a>

        <a class="sidebar-link <?php if ($page == "t_lab") { echo "active";}?>" href="./t_lab_reports.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Lab Reports</a>

        <a class="sidebar-link <?php if ($page == "atd") { echo "active";}?>" href="./t_attendance.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Attendance</a>
                    
        <a class="sidebar-link <?php if ($page == "ass") { echo "active";}?>" href="./t_assessment.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Assessment Tools</a> 
                    
        <a class="sidebar-link <?php if ($page == "tcome") { echo "active";}?> " href="./t_course_outcome.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Course Outcome</a>
                   
        <a class="sidebar-link <?php if ($page == "gp") { echo "active";}?>" href="./t_grading_policy.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"></i>Grading Policy</a>
        <!--   <a class="sidebar-link" href="./d_current_teacher.php"> <i class="bi fright bi-arrow-right-circle"> </i>Current Teacher</a> -->
                
        <a class="sidebar-link <?php if ($page == "fm") { echo "active";}?>" href="./t_final_marksheet.php?course=<?php echo $_SESSION['courseid'] ?>"><i class="bi fright bi-arrow-right-circle"></i>Final Marksheet</a>
                  
        <a class="sidebar-link <?php if ($page == "rp") { echo "active";}?> " href="./t_resultpdf.php?course=<?php echo $_SESSION['courseid'] ?>"> <i class="bi fright bi-arrow-right-circle"> </i>Result PDF</a>
    </div>
</div>


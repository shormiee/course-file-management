<?php 
  include('header_essential.php'); 
  session_start();
  include_once("includes/connection.php");
  $deptId = $_SESSION['deptid'];
?>
<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>
 <h5 class="text-center"> <?php echo $_SESSION['name'] . ", you are accessing department admin panel" ?></h5>; 
  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
<?php
  $dept = "SELECT * FROM 04_department WHERE id = '$deptId' ";
  $result = mysqli_query($conn, $dept);
?>


    <?php include ("./includes/dropdown_filter.php");

      while ($row = mysqli_fetch_assoc($result)):
    ?>
      <input type="text" name="deptid" placeholder="department name" value="<?php echo $row["dept_name"]; ?> ">
    


    <?php endwhile; ?>


    <div class="col-auto">
      <a href="./d_see_courses.php">
  
  </div>
 <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

  <?php
    $page = "";
    include ("./d_main_nav.php");
  ?>
  </div>
</div>

  <!--  -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="js/new.js"></script>

</body>
</html>
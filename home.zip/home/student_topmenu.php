<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-text text-white" style="padding-right: 50px;"><a href="./student.php"> course file management</a></span>
  <!--   <div class="collapse navbar-collapse" id="navbarNavDropdown"> -->
    
      <ul class="navbar-nav ml-auto">
       <li class="nav-item dropdown bg-dark text-white">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          <?php echo $_SESSION['name']; ?>
          </a>
          <ul class="dropdown-menu user-dropdown" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="student_chngpass.php">change password</a></li>
                <li><a class="dropdown-item" href="logout.php">log out</a></li>
           
          </ul>
        </li>
        </ul>
   <!--  </div> -->
  </div>
</nav>
<?php 
  include('header_essential.php'); 

  session_start();
  include_once("includes/connection.php");
  $_SESSION['courseid'] = $_GET['course'];
  $c_id = $_SESSION['courseid'];

  if (isset($_POST['submit'])) {
    $file=$_FILES['filename']['name'];
    $file_type=$_FILES['filename']['type'];
    $file_size=$_FILES['filename']['size'];
    $file_tem_loc=$_FILES['filename']['tmp_name'];
    $file_name=explode(".", $file);
    $file_ext=strtolower(end($file_name));
    $file_store="pdf/".$_POST['name']."_".time().".".$file_ext;
    move_uploaded_file($file_tem_loc,$file_store);

    $old_data = "SELECT * FROM `08_course_file` WHERE course_id = '$c_id'";
    $c_result = mysqli_query($conn, $old_data);
    $c_row = mysqli_fetch_assoc($c_result);

    if ($c_row > 0) {
      $file_id = $c_row['file_id'];
      $old_link = $c_row['lab_reports'];
      if (file_exists($old_link)) {
        unlink($old_link);
      }
      $sql="UPDATE `08_course_file` SET `lab_reports`= '$file_store' WHERE file_id = '$file_id'";
      $query=mysqli_query($conn,$sql);
    }

    else{
      $teacher_id = $_SESSION['id'];
      $course_id = $_POST['course_id'];
      $sql="INSERT INTO 08_course_file(lab_reports,teacher_id,course_id) values('$file_store','$teacher_id','$course_id')";
      $query=mysqli_query($conn,$sql);
    }
  }
?>


<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "teacher_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>


</div>
  </div>


 <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

      <?php
     $page = "t_lab";
    include ("./t_sidenav.php");
     ?>
</div>

<div class="col-sm-5 shadow-sm" style="margin-top: 30px; margin-right: auto; height: 360px;"> 
<div class="justify-content-center"> 


 

<div class="row">
  <div class="col-10 col-sm-10 col-lg-8"> 
<a style="color: black;" href="./t_my_courses.php">my courses</a>
    <h3>Lab Reports</h3>

<form method="post" enctype="multipart/form-data">
    <div class="form-group row my-3">
    <label for="name" class="col-sm-4 col-form-label">File Name:</label>
    <div class="col-sm-7">
      <input type="text" class="form-control" id="name" name="name" placeholder="Enter file name" required>
    </div>
  </div>
  <div class="form-group row my-3">
 <label for="filename" class="col-sm-4 col-form-label required">Upload File:</label>

    <div class="col-sm-6">
      <input type="file" class="custom-file-input" id="filename" name="filename" required>
    </div>
  </div>
 

  
  <div class="form-group row">
     <div class="mt-3">
      <button type="submit" name="submit" class="btn text-white bg-dark">Submit</button>
    </div>
  </div>
</form>
 </div>
</div>
</div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>
</body>

</html>
<?php
  session_start();
  include_once("includes/connection.php");
  $_SESSION['courseid']  = $_GET['id'];

  function download($file)
  {
    if(!$file)
    {
       // File doesn't exist, output error
      die('file not found');
    }
    else
    {
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename='.basename($file));
      header('Content-Transfer-Encoding: binary');
      header('Expires: 0');
      header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
      header('Pragma: public');
      header('Content-Length: ' . filesize($file));
      ob_clean();
      flush();
      readfile($file);
      exit;
    }
  }

  if(isset($_GET['click'])){
      download($_GET['click']);
    }
?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
</head>

<body>
  <div class="menu">
  <?php include "student_topmenu.php"; ?>
 </div>

  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
     
  </div>
</div>
  </div>


 <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

    <?php
      $page = "st1";
      include ("./st_sidenav.php");
    ?>
</div>

<div class="col-sm-5" style="margin-top: 30px; margin-right: auto;"> 
<div class="justify-content-center"> 
<!-- <div class="table-responsive-sm"> -->
<table class="table" style= "border: 1px solid #979696;">
  <thead class="table-dark">
    <tr>
      <th scope="col">File Name</th>
      <th scope="col">Download Link</th>
    </tr>

  </thead>
 <tbody>

  <?php
    $course = $_SESSION['courseid'];
    $year = $_SESSION['current_year'];
    $semester = $_SESSION['current_semester'];
    $course_file = "SELECT * FROM 08_course_file,06_course WHERE course_id = '$course' AND 08_course_file.course_id = 06_course.id AND 06_course.year = '$year' AND 06_course.semester_name = '$semester'";
    if ($result = mysqli_query($conn, $course_file)):
    while ($row = mysqli_fetch_assoc($result)):
  ?>
    <tr>
      <th scope="row">Prerequisite</th>
      <td class="col-md-3">
        <button onclick="document.location.href='d_all_course_file.php?click=<?php echo $row['prerequisite'] ?>'" class="btn"><i class="bi bi-download"></i>
          <?php 
            $file=explode("/", $row['prerequisite']);
            $file_name=strtolower(end($file));
            echo $file_name;
          ?>
        </button>
      </td>
    </tr>
   <?php endwhile; endif; ?>
</tbody>

</table>
</div>



</div>

</div>




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


</html>
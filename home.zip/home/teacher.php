<?php
session_start();

?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Course File Management System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.6.1/font/bootstrap-icons.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">

</head>
<body>
  <div class="menu">
  <?php include "teacher_topmenu.php"; ?>
 </div>
 <h3 class="text-center"> <?php echo $_SESSION['name'] . ", welcome to Teacher's panel" ?></h3>; 
  <div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>


</div>
  </div>

   <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
     <div class="sidebar d-admin-sidenav">
                <div class="nav list-group">

<a class="sidebar-link " href="./t_my_courses.php"> <i class="bi fright bi-arrow-right-circle"></i>My Courses</a>
</div>

  </div>
</div>

  <!--  --> 

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


</html>
<?php
  include_once("includes/connection.php");

     if (isset($_POST['submit'])) {
          $file=$_FILES['file'];
          $fileName=$_FILES['file']['name'];
          $file_type=$_FILES['file']['type'];
          $file_size=$_FILES['file']['size'];
          $file_tem_loc=$_FILES['file']['tmp_name'];
          $file_store="pdf/".$file;

          move_uploaded_file($file_tem_loc,$file_store);

          $sql="INSERT INTO 08_course_file('prerequisite') values('$file')";


          $query=mysqli_query($conn,$sql);
        }
?>

<?php
  session_start();
include_once('header_essential.php'); 

 include_once("includes/connection.php");  

?>

<body>
  <div class="menu">
  <?php include "d_topmenu.php"; ?>
 </div>

<div class="filter-section">
<div class="row gy-2 gx-3 justify-content-md-center">
    <?php include ("./includes/dropdown_filter.php"); ?>

    <div class="col-auto">
   <!-- <input type="button" name="ans" value="submit" class="btn btn-dark" onclick="document.getElementById('sidebar').style.display = 'block' ;" /> -->
  </div>
</div>
</div>

  <div class="row pb-5">

 <div class="col-3 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">

       <?php
     $page = "d_one";
    include ("./d_main_nav.php");
     ?>
  </div>


  <div class="col-md-9">
  

 <div class="col-10 col-sm-10 col-lg-8"> 

<!-- <div class="table-responsive-sm"> -->
<table class="table" style= "border: 1px solid #979696;">
  <caption class="caption-top">Course List</caption>
  <thead class="table-dark">
    <tr>
      <th scope="col">Course Title</th>
      <th scope="col">Course-Code</th> 
      <th scope="col">Current Teacher ID</th>
      <th scope="col">Actions</th> 
      <th scope="col"></th> 
    </tr>
  </thead>
  <?php 
    $deptId = $_SESSION['deptid'];
    if (isset($_POST['cy'])) {
        $Selectedyear = $_POST['cy']; 
        $sql = "SELECT * FROM `06_course` WHERE offering_deptid = '$deptId' AND `year`='$Selectedyear'"; 
    }
    else{
       $sql = "SELECT * FROM `06_course` WHERE offering_deptid = '$deptId'";
    }
   

   ?>
  <tbody>
    <?php if ($result = mysqli_query($conn, $sql)):
      while ($row = mysqli_fetch_assoc($result)): ?>
      <tr>
      <th scope="row"><?php echo $row['course_title'] ?></th>
      <td scope="row"><?php echo $row['course_code'] ?></td>
      <td scope="row">
        <?php
          $id = $row['current_teacher_id'];
          if ($id) {
            $res = mysqli_query($conn, "SELECT name FROM `05_teacher` WHERE id= '$id'");
            $trow = mysqli_fetch_assoc($res);
            echo $trow['name'];
          }
        ?>
      </td>

      <td class="col-2">
        <button class="me-2 btn btn-lg text-dark edit-button">
          <a class="btn btn-lg" href="d_course_edit.php?id=<?php echo $row['id'] ?>"><i class="bi bi-pencil-square"></i></a>
        </button>
        <!--<button class="me-2 btn btn-lg text-dark delete-button">
          <i class="bi bi-trash"></i> -->
        </button>
      </td>
      <td class="col-2">
        <a href="./d_all_course_file.php?id=<?php echo $row['id'] ?>"><button class="btn btn-sm bg-dark text-white status">see course Files
        </button></a>
      </td>
    </tr>
  <?php endwhile; endif; ?>
  </tbody>
</table>
</div>
 </div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>


<!-- </html> -->
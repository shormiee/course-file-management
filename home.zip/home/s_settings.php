<?php 
include_once('header_essential.php'); 

session_start();
include_once("includes/connection.php");

if (isset($_POST['save'])) {
  $currentyear = $_POST['cy'];
  $semester = $_POST['sem'];
  $sts = $_POST['sts'];
  $query = "INSERT into 09_settings (current_year , current_semester, status_09) values ('$currentyear' , '$semester', '$sts')";
  $query_run = mysqli_query($conn, $query);

  if($query_run){
     $_SESSION['status'] =  "Records inserted successfully.";

  } else{
    $_SESSION['status'] = "ERROR: Could not able to execute $query " . mysqli_error($conn);
  }
}

?>
<body>
 <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>
 <div class="row">
   <div class="col-3 col-sm-3">
    <?php
     $page = "six"; 
    include ("./super_admin_sidenav.php");
     ?>
  </div>
<div class="col-sm-8" style="margin-top:30px; margin-right: auto;"> 
<div class="justify-content-center"> 
      <div class="col-md-8 shadow-sm">

<?php 
if (isset($_SESSION['status'])) {

  echo "<h4>".$_SESSION['status']."</h4>";
  unset($_SESSION['status']);
}
?>
    <form method="post" action="">
      <h3 class="text-left my-3">Set current year & semester</h3>
      <div class="text-left">
        <label>Choose current year</label>
        <input type="text" class="yearpicker" value="" name="cy" required="">
      </div>
      <div class="text-left">
        <label>Current semester</label>
        <select name="sem" class=" my-2" required="">
          <option value="none" disabled selected>Choose option</option>
          <option value="fall" >fall</option>
          <option value="summer" >summer</option>
          <option value="spring">spring</option> 
        </select>
      </div>
      <div class="text-left  my-2" >
       <label>Status</label>
        <select name="sts" required="">
          <option value="none" disabled selected>Choose option</option>
          <option value="1">activate</option>
          <option value="0">deactivate</option>
      </select>
     </div>
    <input type="submit" name="save" class="btn bg-dark text-white" value="save">
  </form>

  </div>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="js/new.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<link rel="stylesheet" href="css/yearpicker.css" />
<script src="js/yearpicker.js"></script>
<script type="text/javascript">
$(document).ready(function() {
   $(".yearpicker").yearpicker({
      year: 2022,
      startYear: 2019,
      endYear: 2032,
   });
});

</script>
</body>
</html>
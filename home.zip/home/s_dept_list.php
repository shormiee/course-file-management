<?php include('header_essential.php'); ?>
<?php
session_start();
include_once("includes/connection.php");
?>

<body>
 <div class="menu">
  <?php include "superadmin_topmenu.php"; ?>
 </div>

  <div class="row">
   <div class="col-3 col-sm-3">

      <?php
     $page = "two"; 
    include ("./super_admin_sidenav.php");
     ?>
    
  </div>



<div class="col-sm-8" style="margin-top: 30px; margin-right: auto;"> 
<div class="justify-content-center"> 
<!-- <div class="table-responsive-sm"> -->
<table class="table" style= "border: 1px solid #979696;">
  <thead class="table-dark">
    <tr>
      <th scope="col">Department Name</th>
      <th scope="col">Department Code</th>
       <th scope="col">Program Code</th>
      <th scope="col">Total Credit</th>
      <th scope="col">Status</th>
           <th scope="col">Actions</th> 
    </tr>
  </thead>
  <tbody>
    <?php
     $user_query = mysqli_query($conn,"select * from 04_department order by dept_name ")or die(mysqli_error());
      while($row = mysqli_fetch_array($user_query)){
      $id = $row['id'];
      ?>
    <tr>
      <th class="col-md-3"> <?php echo $row['dept_name']; ?>
      </th>
      <td class="col-md-2"><?php echo $row['dept_code']; ?> </td>
      <td class="col-md-2"><?php echo $row['program_code']; ?> </td>
      <td class="col-md-2"><?php echo $row['total_credit']; ?> </td>
        <td class="col-md-1"><?php echo $row['status_04']; ?> </td>

  <td class="col-md-3">
    <a href="./s_update_dept.php?id=<?php echo $row['id']; ?>"><button class="me-2 btn btn-small btn-dark edit-button" name="edit-button"> Edit/Update
        </button></a>
         <!--  <a href="./s_delete_dept.php?id=<?php echo $row['id']; ?>"><button class="me-2 btn btn-small btn-dark delete-button"> Delete
          </button></a> -->
      </td>
     
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>

</div>
</div>





  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="js/new.js"></script>

</body>
</html>  
